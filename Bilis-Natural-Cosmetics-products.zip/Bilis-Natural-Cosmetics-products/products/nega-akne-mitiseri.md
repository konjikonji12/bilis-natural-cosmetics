# Nega za akne, mitisere i nečistu kožu

## Koncept
Biljna nega za kožu sklonu nepravilnostima.

## Komunikacija
Podržava čist, uravnotežen i negovan izgled kože.

Ne koristiti tvrdnje o lečenju akni bez odgovarajuće regulatorne osnove.
