# Zaštitno ulje za brzo tamnjenje

## Koncept
Ulje za negu kože tokom izlaganja suncu i za ujednačen izgled tena.

## Važno
Ako proizvod nema odgovarajući SPF test, ne sme se označavati kao sredstvo za zaštitu od sunca.
