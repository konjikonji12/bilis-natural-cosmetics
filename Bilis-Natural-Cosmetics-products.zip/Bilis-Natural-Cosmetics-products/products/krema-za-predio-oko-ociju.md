# Krema za predeo oko očiju

## Razvijena sirovinska osnova
- Macerat tamjana u devičanskom maslinovom ulju
- Kofein
- Avokado ulje
- Ulje semenki grožđa
- Lanolin

## Namena
Nega osetljive kože oko očiju i negovaniji izgled predela oko očiju.

## Napomena
Konačna procentualna receptura, pH, konzervans i emulzioni sistem moraju biti potvrđeni pre proizvodnje.
