# Nega za proširene vene i kapilare

## Koncept
Biljna nega za osvežavanje kože nogu i prijatan osećaj tokom masaže.

## Komunikacija
Neguje i osvežava noge i doprinosi prijatnom osećaju lakoće.

Ne tvrditi da proizvod leči proširene vene ili kapilare.
