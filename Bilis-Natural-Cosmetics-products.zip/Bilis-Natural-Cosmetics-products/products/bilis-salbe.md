# Bili's Salbe
**Pakovanje:** 50 ml

## Sirovinska osnova
- Devičansko maslinovo ulje
- Macerat ruzmarina
- Macerat kantariona
- Macerat hajdučke trave
- Kokosovo ulje
- Shea puter
- Pčelinji vosak

Macerati su pripremani u devičanskom maslinovom ulju.

## Opis
Bogata prirodna mast za intenzivnu negu i zaštitu kože.

## Napomena
Za konačnu komercijalnu dokumentaciju koristiti tačne procente iz finalne proizvodne recepture.
