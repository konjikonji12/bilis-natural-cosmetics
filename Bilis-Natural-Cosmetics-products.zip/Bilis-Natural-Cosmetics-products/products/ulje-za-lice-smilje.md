# Ulje za lice od smilja
**Pakovanje:** 30 ml

## Naziv
Bili's Natural Cosmetics — Natural Booster IMMORTELLE

## Opis
Prirodno ulje za intenzivnu negu lica sa smiljem, za mekan, gladak i blistav izgled kože.

## Osnova
Biljna ulja i macerat smilja u devičanskom maslinovom ulju.
