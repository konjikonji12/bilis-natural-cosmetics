# Sapun od kantarionovog ulja

## Osnova
Kantarionovo ulje / macerat kantariona u devičanskom maslinovom ulju.

## Opis
Prirodni sapun za svakodnevnu negu kože, sa kantarionovim uljem kao glavnom biljnom karakteristikom.

Za konačnu deklaraciju navesti stvarne sirovine korišćene u saponifikaciji.
