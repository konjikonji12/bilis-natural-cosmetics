# Ulje za negu kod glavobolje i migrene

## Koncept
Biljno ulje za masažu i osećaj opuštanja u predelu slepoočnica i vrata.

## Komunikacija
Umirujući i opuštajući osećaj uz prijatnu biljnu aromu.

Ne navoditi da proizvod leči migrenu ili glavobolju.
