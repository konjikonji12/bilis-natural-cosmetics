# Nega za posekotine, ogrebotine i iritiranu kožu

## Koncept
Blaga biljna formulacija namenjena nezi iritirane kože.

## Komunikacija
Neguje kožu i podržava njen prirodan proces obnove.

Za otvorene rane i medicinske tvrdnje potrebna je posebna regulatorna procena.
