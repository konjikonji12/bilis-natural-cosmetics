# Nega za umorne i teške noge

## Komunikacija
Hladi, osvežava i pruža prijatan osećaj lakoće u nogama.

## Koncept
Proizvod namenjen masaži i svakodnevnoj nezi umornih nogu.
