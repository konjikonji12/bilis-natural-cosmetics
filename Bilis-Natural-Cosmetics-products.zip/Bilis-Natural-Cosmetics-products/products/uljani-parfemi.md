# Prirodni uljani parfemi

## Koncept
Ekskluzivne mirisne kompozicije na bazi visokokvalitetnih ulja.

Za svaki miris voditi poseban dokument sa tačnim sirovinama, koncentracijom, INCI nazivima i alergenima kada je primenljivo.
