# Mast za negu kože kod opekotina

## Koncept
Proizvod je razvijan kao mast za negu kože nakon oštećenja.

## Važno
Ne koristiti tvrdnju da kozmetički proizvod leči ili tretira opekotine. Namenu i regulatornu kategoriju treba jasno definisati.
