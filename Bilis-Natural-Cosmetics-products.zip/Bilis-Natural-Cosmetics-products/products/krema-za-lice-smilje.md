# Krema za lice od smilja
**Pakovanje:** 50 ml

## Opis
Prirodna krema za negu lica sa smiljem, namenjena negovanom, glatkom i blistavom izgledu kože.

## Ključne sirovine
- Smilje / Immortelle / Helichrysum
- Macerat smilja u devičanskom maslinovom ulju
- U ranijem razvoju razmatrana je i kombinacija sa šipkom

## Važno
Ranija tvrdnja o „38% bora“ i formulacija „sa sigurnošću“ su izbačene i ne treba ih vraćati u marketing.
