# Mast za negu kože kod psorijaze, crvenila i ekcema

## Koncept
Bogata biljna mast namenjena suvoj, osetljivoj i iritiranoj koži.

## Komunikacija
Umiruje osećaj nelagodnosti i podržava negovan izgled kože.

Ne koristiti tvrdnje da proizvod leči psorijazu ili ekcem bez odgovarajuće regulatorne osnove.
