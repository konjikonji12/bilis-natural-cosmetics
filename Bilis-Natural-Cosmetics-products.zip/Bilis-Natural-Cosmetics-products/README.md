# Bili's Natural Cosmetics — Proizvodi

Centralna dokumentacija proizvoda brenda Bili's Natural Cosmetics.

## Proizvodi
- Bili's Salbe — prirodna mast
- Krema za lice od smilja
- Ulje za lice od smilja
- Bili's Lip Balm — Vanille
- Krema za predeo oko očiju
- Sapun od kantariona
- Mast za negu kože kod psorijaze, crvenila i ekcema
- Mast za negu kože kod opekotina
- Ulje za negu kod glavobolje i migrene
- Zaštitno ulje za brzo tamnjenje
- Nega za akne, mitisere i nečistu kožu
- Nega za posekotine, ogrebotine i iritiranu kožu
- Nega za proširene vene i kapilare
- Nega za umorne i teške noge
- Prirodni uljani parfemi

Napomena: gde nemamo sačuvanu kompletnu procentualnu recepturu, nisu dodavani izmišljeni procenti.
